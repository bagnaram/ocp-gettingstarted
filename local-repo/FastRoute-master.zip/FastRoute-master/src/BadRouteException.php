<?php

namespace FastRoute;

class BadRouteException extends \LogicException {
}
