<?php

namespace Twig\Profiler\NodeVisitor;

class_exists('Twig_Profiler_NodeVisitor_Profiler');

if (\false) {
    class ProfilerNodeVisitor extends \Twig_Profiler_NodeVisitor_Profiler
    {
    }
}
