<?php

namespace Twig\Profiler;

class_exists('Twig_Profiler_Profile');

if (\false) {
    class Profile extends \Twig_Profiler_Profile
    {
    }
}
