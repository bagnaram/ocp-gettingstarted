<?php

namespace Twig\RuntimeLoader;

class_exists('Twig_RuntimeLoaderInterface');

if (\false) {
    interface RuntimeLoaderInterface extends \Twig_RuntimeLoaderInterface
    {
    }
}
