<?php

namespace Twig\Node;

class_exists('Twig_Node_SandboxedPrint');

if (\false) {
    class SandboxedPrintNode extends \Twig_Node_SandboxedPrint
    {
    }
}
