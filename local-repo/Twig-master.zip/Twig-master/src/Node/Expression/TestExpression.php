<?php

namespace Twig\Node\Expression;

class_exists('Twig_Node_Expression_Test');

if (\false) {
    class TestExpression extends \Twig_Node_Expression_Test
    {
    }
}
