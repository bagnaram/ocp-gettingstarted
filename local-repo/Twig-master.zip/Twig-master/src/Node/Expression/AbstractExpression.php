<?php

namespace Twig\Node\Expression;

class_exists('Twig_Node_Expression');

if (\false) {
    class AbstractExpression extends \Twig_Node_Expression
    {
    }
}
