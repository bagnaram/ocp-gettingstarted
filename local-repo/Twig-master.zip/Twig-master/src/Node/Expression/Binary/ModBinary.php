<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_Mod');

if (\false) {
    class ModBinary extends \Twig_Node_Expression_Binary_Mod
    {
    }
}
