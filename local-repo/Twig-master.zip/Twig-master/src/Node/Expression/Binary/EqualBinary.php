<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_Equal');

if (\false) {
    class EqualBinary extends \Twig_Node_Expression_Binary_Equal
    {
    }
}
