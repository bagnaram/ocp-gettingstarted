<?php

namespace Twig\NodeVisitor;

class_exists('Twig_NodeVisitor_Sandbox');

if (\false) {
    class SandboxNodeVisitor extends \Twig_NodeVisitor_Sandbox
    {
    }
}
