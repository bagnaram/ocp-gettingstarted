<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Extends');

if (\false) {
    class ExtendsTokenParser extends \Twig_TokenParser_Extends
    {
    }
}
