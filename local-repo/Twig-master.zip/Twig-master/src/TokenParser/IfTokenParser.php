<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_If');

if (\false) {
    class IfTokenParser extends \Twig_TokenParser_If
    {
    }
}
