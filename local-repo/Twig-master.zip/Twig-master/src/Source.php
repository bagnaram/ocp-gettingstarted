<?php

namespace Twig;

class_exists('Twig_Source');

if (\false) {
    class Source extends \Twig_Source
    {
    }
}
